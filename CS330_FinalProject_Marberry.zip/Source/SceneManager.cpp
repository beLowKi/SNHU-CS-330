///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}


/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}


/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}


/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}


/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}


/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}


/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}


/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}


/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}


/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}


/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}


/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{		
		int textureID = -1;
		textureID = FindTextureSlot(textureTag);

		// FindTextureSlot return -1 on failure, in which case the shader will not use a texture
		if (textureID != -1) {
			m_pShaderManager->setIntValue(g_UseTextureName, true);
			m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
		}
	}
}


/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}


/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		assert(bReturn == true);
		
		m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
		m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
		m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
		m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
		m_pShaderManager->setFloatValue("material.shininess", material.shininess);
	}
}


/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures() {
	
	bool bReturn = false;

	// Source: https://learn.snhu.edu/d2l/le/news/1918322/8880140/view?ou=1918322
	bReturn = CreateGLTexture(
		"./Textures/rusticwood.jpg",
		"wood"
	);

	bReturn = CreateGLTexture(
		"./Textures/marble_dark_seamless.jpg",
		"marble"
	);

	bReturn = CreateGLTexture(
		"./Textures/pattern_flowers_seamless.jpg",
		"platePattern"
	);
	
	bReturn = CreateGLTexture(
		"./Textures/leather_brown_seamless.jpg",
		"leather"
	);

	bReturn = CreateGLTexture(
		"./Textures/paper_textured_seamless.jpg",
		"paper"
	);

	bReturn = CreateGLTexture(
		"./Textures/rubber_bubble_seamless.jpg",
		"rubber"
	);

	// Source: https://www.freepik.com/free-photo/black-striped-wall_1037768.htm#fromView=search&page=1&position=10&uuid=4ce16bb3-9754-4248-bcad-ebfdf9c0f063&query=smooth+dark+metal+Texture+Seamless
	bReturn = CreateGLTexture(
		"./Textures/black-striped-wall.jpg",
		"metal"
	);

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}


/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL marbleMaterial;
	marbleMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	marbleMaterial.ambientStrength = 0.7f;
	marbleMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	marbleMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
	marbleMaterial.shininess = 35.0f;
	marbleMaterial.tag = "marble";
	
	m_objectMaterials.push_back(marbleMaterial);

	// This is more like varnished wood, so a little shiny
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	woodMaterial.ambientStrength = 0.3f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	woodMaterial.specularColor = glm::vec3(0.15f, 0.15f, 0.15f);
	woodMaterial.shininess = 12.5f;
	woodMaterial.tag = "wood";

	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	ceramicMaterial.ambientStrength = 0.5f;
	ceramicMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	ceramicMaterial.specularColor = glm::vec3(0.25f, 0.25f, 0.25f);
	ceramicMaterial.shininess = 25.0f;
	ceramicMaterial.tag = "ceramic";

	m_objectMaterials.push_back(ceramicMaterial);

	OBJECT_MATERIAL leatherMaterial;
	leatherMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	leatherMaterial.ambientStrength = 0.3f;
	leatherMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	leatherMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	leatherMaterial.shininess = 0.1f;
	leatherMaterial.tag = "leather";

	m_objectMaterials.push_back(leatherMaterial);

	OBJECT_MATERIAL paperMaterial;
	paperMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	paperMaterial.ambientStrength = 0.2f;
	paperMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	paperMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	paperMaterial.shininess = 0.1f;
	paperMaterial.tag = "paper";

	m_objectMaterials.push_back(paperMaterial);

	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	metalMaterial.ambientStrength = 0.45f;
	metalMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	metalMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	metalMaterial.shininess = 20.0f;
	metalMaterial.tag = "metal";

	m_objectMaterials.push_back(metalMaterial);

	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	glassMaterial.ambientStrength = 0.3f;
	glassMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	glassMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	glassMaterial.shininess = 85.0;
	glassMaterial.tag = "glass";

	m_objectMaterials.push_back(glassMaterial);

	OBJECT_MATERIAL rubberMaterial;
	rubberMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	rubberMaterial.ambientStrength = 0.1f;
	rubberMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	rubberMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	rubberMaterial.shininess = 2.0f;
	rubberMaterial.tag = "rubber";

	m_objectMaterials.push_back(rubberMaterial);
}


/***********************************************************
 *  AddLight()
 *
 *  Adds a light to the scene. Supplementary function to SetupSceneLights.
 ***********************************************************/
void SceneManager::AddLight(
	glm::vec3 positionXYZ,
	glm::vec3 ambientColor,
	glm::vec3 diffuseColor,
	glm::vec3 specularColor,
	float focalStrength,
	float specularIntensity,
	//float pConstant,
	//float linear,
	//float quadratic,
	//float innerCutOffDegrees = -1.0f,
	//float outerCutOffDegrees = -1.0f,
	glm::vec3 direction = glm::vec3(0.0f, 0.0f, 0.0f))
{
	// NOTE There's a max of 4 light sources.
	assert(m_numberOfLights < 4);
	
	// Checks that direction is normalized
	// Technically not needed since the shader normalizes the vector regardless
	//assert(direction == glm::normalize(direction));

	m_numberOfLights += 1;

	// Defines the string used to access the light source
	// The m_numberOfLights - 1 is because it uses indices
	std::string accessString = "lightSources[" + std::to_string(m_numberOfLights - 1) + "]";

	// Setting parameters
	m_pShaderManager->setVec3Value(accessString + ".position", positionXYZ);
	
	// Setting direction flag
	if (direction != glm::vec3(0.0f, 0.0f, 0.0f)) {
		m_pShaderManager->setVec3Value(accessString + ".direction", direction);
		m_pShaderManager->setBoolValue(accessString + ".bUseDirection", true);
	}
	else {
		m_pShaderManager->setBoolValue(accessString + ".bUseDirection", false);
	}
	
	//m_pShaderManager->setFloatValue(accessString + ".innerCutOff", glm::radians(innerCutOffDegrees));
	//m_pShaderManager->setFloatValue(accessString + ".outerCutOff", glm::radians(outerCutOffDegrees));

	m_pShaderManager->setVec3Value(accessString + ".ambientColor", ambientColor);
	m_pShaderManager->setVec3Value(accessString + ".diffuseColor", diffuseColor);
	m_pShaderManager->setVec3Value(accessString + ".specularColor", specularColor);
	
	//m_pShaderManager->setFloatValue(accessString + ".constant", pConstant);
	//m_pShaderManager->setFloatValue(accessString + ".linear", linear);
	//m_pShaderManager->setFloatValue(accessString + ".quadratic", quadratic);
	
	m_pShaderManager->setFloatValue(accessString + ".focalStrength", focalStrength);
	m_pShaderManager->setFloatValue(accessString + ".specularIntensity", specularIntensity);
}


/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{

	// Defining position variable
	glm::vec3 position;

	// Base light colors
	glm::vec3 warmLight(1.0f, 0.996f, 0.745f);
	glm::vec3 coolLight(0.592f, 0.769f, 0.902f);


	// Warm, directional light
	position = glm::vec3(-0.5, 10.0f, -10.0f);

	AddLight(
		position,
		warmLight * 0.01f,
		warmLight * 0.6f,
		warmLight * 0.4f,
		32.0f,
		0.1f,
		
		// points back to center
		-position
	);

	// Ambient, cool lighting
	position = glm::vec3(0.0f, 1.0f, 0.0f);

	AddLight(
		position,
		coolLight * 0.5f,
		coolLight * 0.2f,
		coolLight * 0.0f,
		12.0f,
		0.0f
	);


	// Enables lighting in the shader
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Loading textures
	LoadSceneTextures();

	// Defining materials
	DefineObjectMaterials();

	// Setting up lights
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTorusMesh(0.08f);
	
}


/***********************************************************
 *  RotateVec3()
 *
 *  Returns a vector3 rotated around each axis by their 
 *	respective degrees in 'rotationDegreesXYZ'.
 ***********************************************************/
glm::vec3 SceneManager::RotateVec3(
	glm::vec3 vector,
	glm::vec3 rotationDegreesXYZ)
{

	// Output vector
	glm::vec3 rotatedVector = vector;
	
	// Rotation Matrix
	glm::mat4 rotationMatrix = glm::mat4(1.0f);


	// X-axis
	glm::vec3 XrotationAxis(1.0f, 0.0f, 0.0f);
	rotationMatrix = glm::rotate(rotationMatrix, glm::radians(rotationDegreesXYZ.x), XrotationAxis);

	// Y-axis
	glm::vec3 YrotationAxis(0.0f, 1.0f, 0.0f);  
	rotationMatrix = glm::rotate(rotationMatrix, glm::radians(rotationDegreesXYZ.y), YrotationAxis);
	
	// Z-axis
	glm::vec3 ZrotationAxis(0.0f, 0.0f, 1.0f);  
	rotationMatrix = glm::rotate(rotationMatrix, glm::radians(rotationDegreesXYZ.z), ZrotationAxis);

	// Applying rotation
	glm::vec4 transformedVec4 = rotationMatrix * glm::vec4(rotatedVector, 1.0f);
	rotatedVector = glm::vec3(transformedVec4);

	return rotatedVector;
}


/***********************************************************
 *  DrawCoffeeCup()
 *
 *  Draws a coffee cup at the target position. X and Z coordinates
 *  are centered while the Y position refers to the bottom of the cup.
 ***********************************************************/
void SceneManager::DrawCoffeeCup(glm::vec3 posXYZ)
{
	// Defines the center of the bottom of the cup
	float bottomCenterX = posXYZ.x;
	float bottomCenterY = posXYZ.y;
	float bottomCenterZ = posXYZ.z;

	// Defining position variable
	glm::vec3 positionXYZ;

	// Defining scale variable
	glm::vec3 scaleXYZ;

	// Defining rotation variables
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// Many cylindrical shapes will use this variable
	float radius;

	// Resets color
	SetShaderColor(1, 1, 1, 1);

	// Texture and material settings
	SetShaderTexture("wood");
	SetShaderMaterial("wood");


	// Drawing shapes from the bottom-up, starting with a flattened cylinder for the cup's bottom
	radius = 0.63;
	positionXYZ = glm::vec3(bottomCenterX, bottomCenterY, bottomCenterZ);
	scaleXYZ = glm::vec3(radius, 0.21, radius);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetTextureUVScale(1.0f, 0.2f);

	m_basicMeshes->DrawCylinderMesh();


	// Rounded bottom
	radius = 1.0f;
	positionXYZ = glm::vec3(bottomCenterX, bottomCenterY + 0.8f, bottomCenterZ);
	scaleXYZ = glm::vec3(radius, 0.8f, radius);

	ZrotationDegrees = 180.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetTextureUVScale(1.0f, 1.36f);
	
	m_basicMeshes->DrawHalfSphereMesh();


	// Cylindrical top
	positionXYZ = glm::vec3(bottomCenterX, bottomCenterY + 0.8f, bottomCenterZ);

	// The radius is shrunk slightly to match the rounded bottom and rim
	radius -= 0.01235f;
	scaleXYZ = glm::vec3(radius, 0.485f, radius);

	ZrotationDegrees = 0.0;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh(false, false);

	// Skinny Torus for the rim of the cup
	positionXYZ = glm::vec3(bottomCenterX, bottomCenterY + 1.25f, bottomCenterZ);

	XrotationDegrees = 90.0f;

	// The torus needs to look like it's a part cylindrical top, 
	// so the radius needs to be slightly reduced
	radius -= 0.08f;
	scaleXYZ = glm::vec3(radius, radius, radius);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetTextureUVScale(1.0f, 1.0f);
	
	m_basicMeshes->DrawTorusMesh();


	// Cup Handle
	positionXYZ = glm::vec3(bottomCenterX + 0.9f, bottomCenterY + 0.85f, bottomCenterZ);

	XrotationDegrees = 0.0f;
	ZrotationDegrees = -90.0f;

	// Shrinking the handle down
	radius -= 0.21f;
	scaleXYZ = glm::vec3(radius - 0.31f, radius, radius);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetTextureUVScale(0.2f, 1.0f);
	
	m_basicMeshes->DrawHalfTorusMesh();
}


/***********************************************************
 *  DrawBook()
 *
 *  Draws a book at target position. X and Z coordinates
 *	are centered while the Y position refers to the bottom of the book.
 *  bExtraPage being true will draw an additional shape for a page
 *	that sticks out from the rest.
 ***********************************************************/
void SceneManager::DrawBook(
	glm::vec3 posXYZ, 
	glm::vec3 globalRotationDegrees,
	bool bExtraPage = false)
{

	// Center point
	glm::vec3 centerXYZ = posXYZ;

	// Defining position variable
	glm::vec3 positionXYZ;

	// Defines a shape's position relative to the book's center point
	glm::vec3 localPositionXYZ;

	// Defining scale variable
	glm::vec3 scaleXYZ;

	// Rotation variables
	float XrotationDegrees = globalRotationDegrees.x;
	float YrotationDegrees = globalRotationDegrees.y;
	float ZrotationDegrees = globalRotationDegrees.z;

	// Resets color
	SetShaderColor(1, 1, 1, 1);


	/*
	*	Constants that affect local scales and positions.
	*	Changing these might also require changing related positions/scales to match
	*/

	// General
	const float HEIGHT = 3.5f;

	// Covers
	const float COVER_POSITION_X = 1.1f;
	const float COVER_ROTATION_Z = 3.3f;
	const float COVER_LENGTH = 2.3f;
	const float COVER_THICKNESS = 0.1f;

	// Pages
	const glm::vec3 PAGE_TRANSLATION = glm::vec3(0.0f, 0.1f, 0.0f);
	const glm::vec3 PAGE_SCALE = glm::vec3(COVER_LENGTH - 0.08f, 0.1f, HEIGHT - 0.05f);
	
	// Extra page
	const glm::vec3 EXTRA_PAGE_TRANSLATION = glm::vec3(0.12f, 0.042f, -1.7f);
	const float EXTRA_PAGE_XROTATION_DEGREES = 90.0f;
	const float EXTRA_PAGE_YROTATION_DEGREES = -14.0f;
	const float EXTRA_PAGE_ZROTATION_DEGREES = -13.0f;
	const glm::vec3 EXTRA_PAGE_SCALE = glm::vec3(1.05f, HEIGHT - 0.13f, 0.13f);
	

	/*
	* Drawing local shapes
	*/

	// Spine
	positionXYZ = centerXYZ;
	scaleXYZ = glm::vec3(0.5f, COVER_THICKNESS * 1.15, HEIGHT);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("leather");
	SetTextureUVScale(2.0f, 0.5f);

	SetShaderMaterial("leather");

	m_basicMeshes->DrawBoxMesh();


	// Left side
	localPositionXYZ = RotateVec3( glm::vec3(-COVER_POSITION_X, 0.03f, 0.0f), globalRotationDegrees );

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = glm::vec3(COVER_LENGTH, COVER_THICKNESS, HEIGHT);
	
	ZrotationDegrees = globalRotationDegrees.z + COVER_ROTATION_Z;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetTextureUVScale(2.5f, 0.6f);

	m_basicMeshes->DrawBoxMesh();


	// Left Pages
	localPositionXYZ += RotateVec3(PAGE_TRANSLATION, globalRotationDegrees);
	
	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = PAGE_SCALE;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("paper");
	SetTextureUVScale(0.8f, 0.8f);

	SetShaderMaterial("paper");

	m_basicMeshes->DrawBoxMesh();


	// {Optional} extra page on left side
	if (bExtraPage) {
		localPositionXYZ += RotateVec3(EXTRA_PAGE_TRANSLATION, globalRotationDegrees);

		positionXYZ = centerXYZ + localPositionXYZ;
		scaleXYZ = EXTRA_PAGE_SCALE;

		XrotationDegrees = globalRotationDegrees.x + EXTRA_PAGE_XROTATION_DEGREES;
		YrotationDegrees = globalRotationDegrees.y + EXTRA_PAGE_YROTATION_DEGREES;
		ZrotationDegrees = globalRotationDegrees.z + EXTRA_PAGE_ZROTATION_DEGREES;

		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ
		);

		m_basicMeshes->DrawCylinderMesh(false, false, true);
	}
	

	// Right side
	localPositionXYZ = RotateVec3(glm::vec3(COVER_POSITION_X, 0.03f, 0.0f), globalRotationDegrees);

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = glm::vec3(COVER_LENGTH, COVER_THICKNESS, HEIGHT);

	// Resets rotation in case of bExtraPage
	XrotationDegrees = globalRotationDegrees.x;
	YrotationDegrees = globalRotationDegrees.y;

	ZrotationDegrees = globalRotationDegrees.z - COVER_ROTATION_Z;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("leather");
	SetTextureUVScale(2.5f, 0.6f);

	SetShaderMaterial("leather");

	m_basicMeshes->DrawBoxMesh();


	// Right pages
	localPositionXYZ += RotateVec3(PAGE_TRANSLATION, globalRotationDegrees);

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = PAGE_SCALE;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("paper");
	SetTextureUVScale(0.8f, 0.8f);

	SetShaderMaterial("paper");

	m_basicMeshes->DrawBoxMesh();
}


/***********************************************************
 *  DrawPlate()
 *
 *  Draws a plate at target position. X and Z coordinates
 *	are centered while the Y position refers to the bottom of the plate.
 ***********************************************************/
void SceneManager::DrawPlate(glm::vec3 posXYZ)
{
	
	// The center of the plate
	glm::vec3 centerXYZ = posXYZ;

	// Defining position variable
	glm::vec3 positionXYZ;

	// Shapes' position relative to the center
	glm::vec3 localPositionXYZ;

	// Defining scale variable
	glm::vec3 scaleXYZ;

	// Defining rotation variables
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// Many cylindrical shapes will use this variable
	float radius;

	// Resets color
	SetShaderColor(1, 1, 1, 1);


	// Cylindrical bottom
	localPositionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	positionXYZ = centerXYZ + localPositionXYZ;

	radius = 0.8f;
	scaleXYZ = glm::vec3(radius, 0.065f, radius);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("wood");
	SetTextureUVScale(0.2f, 0.2f);
	
	SetShaderMaterial("wood");

	m_basicMeshes->DrawCylinderMesh(false, true, true);

	
	// Base
	localPositionXYZ = glm::vec3(0.0f, 0.27f, 0.0f);
	positionXYZ = centerXYZ + localPositionXYZ;

	radius = 1.4f;
	scaleXYZ = glm::vec3(radius, 0.25f, radius);

	ZrotationDegrees = 180.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("platePattern");
	SetTextureUVScale(1.2f, 1.2f);
	SetShaderMaterial("ceramic");

	m_basicMeshes->DrawHalfSphereMesh();
}


/***********************************************************
 *  DrawGlasses()
 *
 *  Draws folded glasses at target position. X and Z coordinates
 *	are centered while the Y position refers to the bottom of the glasses.
 ***********************************************************/
void SceneManager::DrawGlasses(
	glm::vec3 posXYZ,
	glm::vec3 globalRotationDegrees)
{
	// Center point
	// In this case, this point is the midpoint from the center of the glasses' lenses/rims
	glm::vec3 centerXYZ = posXYZ;

	// Defining position variable
	glm::vec3 positionXYZ;

	// Defines a shape's position relative to the book's center point
	glm::vec3 localPositionXYZ;

	// Defining scale variable
	glm::vec3 scaleXYZ;

	// Rotation variables
	float XrotationDegrees = globalRotationDegrees.x;
	float YrotationDegrees = globalRotationDegrees.y;
	float ZrotationDegrees = globalRotationDegrees.z;

	// Resets color
	SetShaderColor(1, 1, 1, 1);


	/*
	*	Constants that affect local scales and positions.
	*	Changing these might also require changing related positions/scales to match
	*/

	// General


	// Rim
	const float RIM_POSITION_X = 0.8f;
	const glm::vec3 RIM_SCALEXYZ = glm::vec3(0.6f, 0.6f, 0.8f);
	
	// Lens
	const float LENS_TRANSPARENCY = 0.05f;
	const float LENS_DEPTH = 0.015f;
	const glm::vec3 LENS_SCALEXYZ = glm::vec3(0.6f, 0.03f, 0.6f);

	// Bridge
	const float BRIDGE_HEIGHT = 0.2f;
	const glm::vec3 BRIDGE_SCALE = glm::vec3(0.26f, 0.15f, 0.5f);

	// Ear rest
	const float EAR_REST_POSITION_X = 1.4f;
	const float EAR_REST_POSITION_Y = 0.0f;
	const float EAR_REST_POSITION_Z = -0.03f;

	const glm::vec3 EAR_REST_SCALE = glm::vec3(0.02f, 2.7f, 0.02f);

	const float EAR_REST_XROTATION_DEGREES = -120.0f;
	const float EAR_REST_YROTATION_DEGREES = 0.0f;
	const float EAR_REST_ZROTATION_DEGREES = -80.0f;

	// Rubber base
	// Instead of using constants like the ones above, these use relative translations and transforms
	// because the ear rests aren't oriented the same.

	const glm::vec3 RUBBER_BASE_SCALE = glm::vec3(0.035f, 1.3f, 0.035f);

	// Translation from the its respective ear rest
	const float RUBBER_BASE_XTRANSLATE = 1.4f;
	const float RUBBER_BASE_YTRANSLATE = -0.13f;
	const float RUBBER_BASE_ZTRANSLATE = -0.2225f;

	// Rubber end
	const glm::vec3 RUBBER_END_SCALE = glm::vec3(0.035f, 0.6f, 0.035f);
	
	// These translations/transformations are relative to the rubber base
	const float RUBBER_END_XTRANSLATE = 1.2625f;
	const float RUBBER_END_YTRANSLATE = -0.105f;
	const float RUBBER_END_ZTRANSLATE = -0.193f;

	// Adds to rubber base rotation
	const glm::vec3 RUBBER_END_ROTATION_TRANSFORMXYZ = glm::vec3(0.0f, 35.0f, 10.0f);


	/*
	* Drawing local shapes
	*/

	// Rim 1
	localPositionXYZ = RotateVec3(glm::vec3(-RIM_POSITION_X, 0.0f, 0.0f), globalRotationDegrees);

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = RIM_SCALEXYZ;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.5f, 1.5f);

	SetShaderMaterial("metal");

	m_basicMeshes->DrawTorusMesh();


	// Lens 1
	localPositionXYZ -= RotateVec3(glm::vec3(0.0f, 0.0f, LENS_DEPTH), globalRotationDegrees);
	
	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = LENS_SCALEXYZ;

	XrotationDegrees = globalRotationDegrees.x + 90.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderColor(1, 1, 1, LENS_TRANSPARENCY);
	SetShaderMaterial("glass");

	// Enables proper transparancy
	glDepthMask(GL_FALSE);

	m_basicMeshes->DrawCylinderMesh(true, true, false);

	// Resetting
	glDepthMask(GL_TRUE);


	// Rim 2
	localPositionXYZ = RotateVec3(glm::vec3(RIM_POSITION_X, 0.0f, 0.0f), globalRotationDegrees);

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = RIM_SCALEXYZ;

	XrotationDegrees = globalRotationDegrees.x;
	YrotationDegrees = globalRotationDegrees.y;
	ZrotationDegrees = globalRotationDegrees.z;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.5f, 1.5f);

	SetShaderMaterial("metal");

	m_basicMeshes->DrawTorusMesh();


	// Lens 2
	localPositionXYZ -= RotateVec3(glm::vec3(0.0f, 0.0f, LENS_DEPTH), globalRotationDegrees);
	
	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = LENS_SCALEXYZ;

	XrotationDegrees = globalRotationDegrees.x + 90.0f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderColor(1, 1, 1, LENS_TRANSPARENCY);
	SetShaderMaterial("glass");

	// Enables proper transparancy
	glDepthMask(GL_FALSE);

	m_basicMeshes->DrawCylinderMesh(true, true, false);

	// Resetting
	glDepthMask(GL_TRUE);


	// Nose bridge
	localPositionXYZ = RotateVec3(glm::vec3(0.0f, BRIDGE_HEIGHT, 0.0f), globalRotationDegrees);
	
	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = BRIDGE_SCALE;

	XrotationDegrees = globalRotationDegrees.x;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.5f, 1.5f);

	SetShaderMaterial("metal");

	m_basicMeshes->DrawHalfTorusMesh();


	// Ear rest 1
	localPositionXYZ = RotateVec3(glm::vec3(-EAR_REST_POSITION_X, EAR_REST_POSITION_Y, EAR_REST_POSITION_Z), globalRotationDegrees);

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = EAR_REST_SCALE;

	XrotationDegrees = globalRotationDegrees.x + EAR_REST_XROTATION_DEGREES;
	YrotationDegrees = globalRotationDegrees.y + EAR_REST_YROTATION_DEGREES;
	ZrotationDegrees = globalRotationDegrees.z + EAR_REST_ZROTATION_DEGREES;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetTextureUVScale(0.5f, 2.0f);

	m_basicMeshes->DrawCylinderMesh();


	/*
	* Ear rest rubber end 1
	*/

	// Base
	localPositionXYZ += RotateVec3(glm::vec3(RUBBER_BASE_XTRANSLATE, RUBBER_BASE_YTRANSLATE, RUBBER_BASE_ZTRANSLATE), globalRotationDegrees);

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = RUBBER_BASE_SCALE;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("rubber");
	SetTextureUVScale(2.5f, 2.5f);

	SetShaderMaterial("rubber");

	m_basicMeshes->DrawCylinderMesh(false, true, true);


	// End
	localPositionXYZ += RotateVec3(glm::vec3(RUBBER_END_XTRANSLATE, RUBBER_END_YTRANSLATE, RUBBER_END_ZTRANSLATE), globalRotationDegrees);

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = RUBBER_END_SCALE;

	XrotationDegrees += RUBBER_END_ROTATION_TRANSFORMXYZ.x;
	YrotationDegrees += RUBBER_END_ROTATION_TRANSFORMXYZ.y;
	ZrotationDegrees += RUBBER_END_ROTATION_TRANSFORMXYZ.z;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	m_basicMeshes->DrawCylinderMesh(true, false, true);


	// Ear rest 2
	localPositionXYZ = RotateVec3(glm::vec3(EAR_REST_POSITION_X, EAR_REST_POSITION_Y - 0.05f, EAR_REST_POSITION_Z), globalRotationDegrees);

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = EAR_REST_SCALE;

	XrotationDegrees = globalRotationDegrees.x + EAR_REST_XROTATION_DEGREES - 10.0f;
	YrotationDegrees = globalRotationDegrees.y + EAR_REST_YROTATION_DEGREES;
	ZrotationDegrees = globalRotationDegrees.z - EAR_REST_ZROTATION_DEGREES + 2.5f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(1.5f, 1.5f);

	SetShaderMaterial("metal");

	m_basicMeshes->DrawCylinderMesh();


	/*
	* Ear rest rubber end 2
	*/

	// Base
	localPositionXYZ += RotateVec3(glm::vec3(-RUBBER_BASE_XTRANSLATE, RUBBER_BASE_YTRANSLATE, RUBBER_BASE_ZTRANSLATE), globalRotationDegrees);

	// Adjusting to the second ear rest's different rotation
	localPositionXYZ += RotateVec3(glm::vec3(0.0f, 0.0f, 0.08f), globalRotationDegrees);

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = RUBBER_BASE_SCALE;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("rubber");
	SetTextureUVScale(2.5f, 2.5f);

	SetShaderMaterial("rubber");

	m_basicMeshes->DrawCylinderMesh(false, true, true);


	// End
	localPositionXYZ += RotateVec3(glm::vec3(-RUBBER_END_XTRANSLATE, RUBBER_END_YTRANSLATE, RUBBER_END_ZTRANSLATE), globalRotationDegrees);

	// Adjusting to the second ear rest's different rotation
	localPositionXYZ += RotateVec3(glm::vec3(0.0f, 0.005f, 0.063f), globalRotationDegrees);

	positionXYZ = centerXYZ + localPositionXYZ;
	scaleXYZ = RUBBER_END_SCALE;

	XrotationDegrees -= RUBBER_END_ROTATION_TRANSFORMXYZ.x;
	YrotationDegrees -= RUBBER_END_ROTATION_TRANSFORMXYZ.y;
	ZrotationDegrees -= RUBBER_END_ROTATION_TRANSFORMXYZ.z + 2.8f;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	m_basicMeshes->DrawCylinderMesh(false, true, true);


	// Nose rest rubber bit 1


	// Nose rest rubber bit 2


}


/***********************************************************
 *  DrawTablePlane()
 *
 *  Draws a plane to represent the table/counter in the original image.
 *	It's positioned at (0, 0, 0).
 ***********************************************************/
void SceneManager::DrawTablePlane()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;
	
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// Texture and material settings
	SetShaderTexture("marble");
	SetShaderMaterial("marble");
	SetTextureUVScale(1.75f, 1.75f);

	//glColor4f(1.0f, 0.0f, 0.0f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	
	//glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	DrawTablePlane();

	// Positioning variables
	glm::vec3 globalPositionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	glm::vec3 globalRotationDegreesXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	
	// Plate and coffee cup
	globalPositionXYZ = glm::vec3(1.4f, 0.01f, -0.4f);
	DrawPlate(globalPositionXYZ);
	
	globalPositionXYZ.y = 0.08f;
	DrawCoffeeCup(globalPositionXYZ);


	// 3 books
	globalPositionXYZ = glm::vec3(-2.3f, 0.05f, -1.2f);
	globalRotationDegreesXYZ = glm::vec3(0.0f, 55.0f, 0.0f);
	DrawBook(globalPositionXYZ, globalRotationDegreesXYZ);
	
	globalPositionXYZ = glm::vec3(0.7f, 0.22f, -4.0f);
	globalRotationDegreesXYZ = glm::vec3(-2.2f, 15.0f, -2.2f);
	DrawBook(globalPositionXYZ, globalRotationDegreesXYZ, true);
	
	globalPositionXYZ = glm::vec3(-1.2f, 0.22f, 2.8f);
	globalRotationDegreesXYZ = glm::vec3(2.2f, 70.0f, 1.8f);
	DrawBook(globalPositionXYZ, globalRotationDegreesXYZ, false);


	// Glasses on top of 3rd book
	globalPositionXYZ = glm::vec3(-0.25f, 0.95f, 2.0f);
	globalRotationDegreesXYZ = glm::vec3(-80.0f, 0.0f, 0.0f);
	DrawGlasses(globalPositionXYZ, globalRotationDegreesXYZ);
}
